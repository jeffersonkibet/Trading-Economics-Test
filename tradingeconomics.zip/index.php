<html>
<head>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<title>
Trading Economics: CHINA EXPORTS TO USA and USA EXPORTS TOC CHINA.
</title>

<script src="http://dygraphs.com/2.1.0/dygraph.min.js"></script>
<script src="http://dygraphs.com/2.1.0/dygraph.js"></script>
<link rel="stylesheet" href="http://dygraphs.com/2.1.0/dygraph.css" />

  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
 
  
  <script>
/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}

</script>


<script>
(function() {
	
	function Slideshow( element ) {
		this.el = document.querySelector( element );
		this.init();
	}
	
	Slideshow.prototype = {
		init: function() {
			this.wrapper = this.el.querySelector( ".slider-wrapper" );
			this.slides = this.el.querySelectorAll( ".slide" );
			this.previous = this.el.querySelector( ".slider-previous" );
			this.next = this.el.querySelector( ".slider-next" );
			this.index = 0;
			this.total = this.slides.length;
			this.timer = null;
			
			this.action();
			this.stopStart();	
		},
		_slideTo: function( slide ) {
			var currentSlide = this.slides[slide];
			currentSlide.style.opacity = 1;
			
			for( var i = 0; i < this.slides.length; i++ ) {
				var slide = this.slides[i];
				if( slide !== currentSlide ) {
					slide.style.opacity = 0;
				}
			}
		},
		action: function() {
			var self = this;
			self.timer = setInterval(function() {
				self.index++;
				if( self.index == self.slides.length ) {
					self.index = 0;
				}
				self._slideTo( self.index );
				
			}, 5000);
		},
		stopStart: function() {
			var self = this;
			self.el.addEventListener( "mouseover", function() {
				clearInterval( self.timer );
				self.timer = null;
				
			}, false);
			self.el.addEventListener( "mouseout", function() {
				self.action();
				
			}, false);
		}
		
		
	};
	
	document.addEventListener( "DOMContentLoaded", function() {
		
		var slider = new Slideshow( "#main-slider" );
		
	});
	
	
})();



</script>
<script>
$(function () { $('.popover-show').popover('show');});
$(function () { $('.popover-hide').popover('hide');});
$(function () { $('.popover-destroy').popover('destroy');});
$(function () { $('.popover-toggle').popover('toggle');});
$(function () { $(".popover-options a").popover({html : true });});
</script>

<style type="text/css">
html,body {
	margin: 0;
	padding: 0;
}
.slider {
	width: 100%;
	
	
}

.slider-wrapper {
	width: 100%;
	height: 80%;
	position: relative;
}

.slide {
	float: left;
	position: absolute;
	width: 100%;
	height: 100%;
	opacity: 0;
	transition: ease-in-out 6s linear;
	
}

.slider-wrapper > .slide:first-child {
	opacity: 1;
}

/* Remove margins and padding from the list, and add a black background color */
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #02644c;
}

ul.topnavv {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
	color:#02644c;
    background-color: background:rgba(2, 100, 76, 0.6);
}

/* Float the list items side by side */
ul.topnav li {float: right;}
ul.topnavv li {float: left;}

/* Style the links inside the list items */
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}

ul.topnavv li a {
    display: inline-block;
    color: #02644c;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 10px;
}

/* Change background color of links on hover */
ul.topnav li a:hover {background-color: #151E40;}
ul.topnavv li a:hover {color: #ffffff; background-color: #02644c;}

/* Hide the list item that contains the link that should open and close the topnav on small screens */
ul.topnav li.icon {display: none;}
ul.topnavv li.icon {display: none;}


/* When the screen is less than 680 pixels wide, hide all list items, except for the first one ("Home"). Show the list item that contains the link to open and close the topnav (li.icon) */
@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}

@media screen and (max-width:680px) {
  ul.topnavv li:not(:first-child) {display: none;}
  ul.topnavv li.icon {
    float: right;
    display: inline-block;
  }
}

/* The "responsive" class is added to the topnav with JavaScript when the user clicks on the icon. This class makes the topnav look good on small screens */
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}

/* The "responsive" class is added to the topnav with JavaScript when the user clicks on the icon. This class makes the topnav look good on small screens */
@media screen and (max-width:680px) {
  ul.topnavv.responsive {position: relative;}
  ul.topnavv.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnavv.responsive li {
    float: none;
    display: inline;
  }
  ul.topnavv.responsive li a {
    display: block;
    text-align: left;
  }
}




</style>
<style>



div.polaroid {
  width: 100%;
  background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 20px;
  margin-top: 20px;
  margin-left:5px;
}

div.containerpalaroid {
  text-align: center;
  padding: 10px 20px;
}
</style>
 <meta charset="utf-8">
<meta name="description"
content="zealousinformatics.com is a Freelance website for Web design, web development,Android Development, Research,Mobile data collection tools design,Data analysis,Time series data analysis and data analytics " />

<meta name="robots"
content=" " />
<meta http-equiv="author"
content="Zealous Informatics" />
<meta http-equiv="pragma"
content="no-cache" />
<style type= "text/css">
#wss{
opacity:0;
-webkit-transition:opacity 1.0s linear 0s;
transition:opacity 1.0s linear 0s;

}

</style>

<script>
var wss_i = 0;
var wss_array = ["Videos","JOKES","Entertainment","Event Enterntainment","News"];
var wss_elem;
 
function wssNext(){
wss_i++; 
wss_elem.style.opacity = 0;
if(wss_i > (wss_array.length - 1)){
wss_i = 0;
}
setTimeout('wssSlide()',1000);
} 
function wssSlide(){
wss_elem.innerHTML = wss_array[wss_i];
wss_elem.style.opacity = 1;
setTimeout('wssNext()',2000);
 
}

</script>
 <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/animate.css">
  <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900|Montserrat:400,700' rel='stylesheet' type='text/css'>
  

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/main.css">
  

  <script src="js/modernizr-2.7.1.js"></script>
  <link rel="icon" 
      type="image/png" 
      href="img/images/favicon.png">
  
  
  

</head>

<body>

<div>
<div class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="logo" href="index.html"><h5 class ="wow fadeIn"> <h2></a>
        </div>
        <div class="navbar-collapse collapse">
		
		<ul>
	<a href="index.php"></a>
		</ul>
		
          <ul class="nav navbar-nav navbar-right ">
            






			
			</ul>
		
		
			 
            
          </ul>
        </div><!--/.navbar-collapse -->
      </div>
    </div>

<nav class="navbar  navbar-default" role="navigation">
<div class="navbar-header"> </div>
</div>



<div>

<ul class="topnav" id="myTopnav">


<li class="icon">
    <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
  </li>
</ul>


</div>


<section id="intro" class="raw" style="margin-top:10%;">

 <h1 style="text-align:center;"> CHINA USA TRADING TIME SERIES  </h1> 
<div class="col-md-2">

</div>
<?php

/* Geting Data for USA Exports to CHINA */


	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://api.tradingeconomics.com/comtrade/historical/USACHN00002?c=guest%3Aguest&f=json",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "postman-token: 6faf6144-cfbf-0f24-05c5-efbd5b32b806"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
	$temp_array =array();
    $year = array();
    $pointarray = array();
	$pointarray1 = array();
    $myarray = array();
  
	$decodedjson = json_decode($response,true);
  $temp_array =array();
  
  
  
  
 $newencoded = json_encode(array("students"=>$decodedjson));
  $obj = json_decode($newencoded,true);
  
  for($i=0; $i<count($obj['students']); $i++) {
    
	
	$temp_array[] =$obj['students'][$i]["value"];
	 $yearstring = substr($obj['students'][$i]["date"],0,4);
    $year[] =(int)$yearstring;	
	
}

$seriesvalues1= json_encode($temp_array);
$seriesyear1 = json_encode($year);
/*echo "<hr>";
echo json_encode($temp_array);
echo "<hr>";
echo json_encode($year);

echo "<hr>";

*/
for($i=0; $i<count($obj['students']); $i++) {
    
	
	     
	 $yearstring = substr($obj['students'][$i]["date"],0,4);
           $yearint =(int)$yearstring;
	 
	$point = array($yearint,$obj['students'][$i]["value"]);
			 
			 $pointarray1[] = $point;
			 
			

	
  }
   echo "<hr>";
  

  /*echo json_encode($pointarray);*/
  
  echo '<div class="col-md-4">';
echo '<h2> US to China Exports </h2>';
  /*Graph One:Dygraphs*/
echo  '<div id="graphdivvv">
<script type="text/javascript">

g=new Dygraph(document.getElementById("graphdivvv"),';
           echo json_encode($pointarray1)
	  
	  
	  
               .
              ',
              {
				
  
  
                labels: [ "x", "A" ]
              });
  
</script>
</div>';
  echo "</div>";
  
  
	
	
	
	
}
	
	
	






	
	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://api.tradingeconomics.com/comtrade/historical/CHNUSA00002?c=guest%3Aguest&f=json",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "postman-token: 6faf6144-cfbf-0f24-05c5-efbd5b32b806"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
	
	$temp_array =array();
    $year = array();
    $pointarray = array();
    $myarray = array();
  
	$decodedjson = json_decode($response,true);
  $temp_array =array();
  
  
  
  
 $newencoded = json_encode(array("students"=>$decodedjson));
  $obj = json_decode($newencoded,true);
  
  for($i=0; $i<count($obj['students']); $i++) {
    
	
	$temp_array[] =$obj['students'][$i]["value"];
	 $yearstring = substr($obj['students'][$i]["date"],0,4);
    $year[] =(int)$yearstring;	
	
}

   $seriesvalues2= json_encode($temp_array);
   $seriesyear2 = json_encode($year);

/*echo json_encode($temp_array);
echo json_encode($year);*/


for($i=0; $i<count($obj['students']); $i++) {
    
	
	     
	 $yearstring = substr($obj['students'][$i]["date"],0,4);
           $yearint =(int)$yearstring;
	 
	$point = array($yearint,$obj['students'][$i]["value"]);
			 
			 $pointarray[] = $point;
			 
			 
			 
			 
			

	
  }
 /*  echo "<hr>";
  

  echo json_encode($pointarray);
  
  echo "<hr>";*/
  
  
	
	
}
	
	
	








	
	echo '<div class="col-md-4" style="margin-left:20%;">';
	echo '<h2> China to US Exports </h2>';
  /*Graph One:Dygraphs*/
echo  '<div id="graphdivv">
<script type="text/javascript">

g=new Dygraph(document.getElementById("graphdivv"),';
           echo json_encode($pointarray)
	  
	  
	  
               .
              ',
              {
				
  
  
                labels: [ "x", "A" ]
              });
  
</script>
</div>';
  echo "</div>";
  echo '</section>';
 echo'<section  class="raw">
<div class="col-md-2">

</div>' ;
   
  /*
  
  echo json_encode($pointarray);
 
 echo "<hr>";*/
 echo '<div class="col-md-8">';
 echo '<div id="myDiv" >';
 echo "<script>
 
 var trace1 = {
  type: 'scatter',
  mode: 'lines',
  name: 'CHINA TO USA',
  x:".$seriesyear2.",
  y:".$seriesvalues2.",
  line: {color: '#FF0000'}
}

var trace2 = {
  type: 'scatter',
  mode: 'lines',
  name: 'USA TO CHINA',
  x:".$seriesyear1.",
  y:".$seriesvalues1.",
  line: {color: '#013cFE'}
}

var data = [trace1,trace2];
 var layout = {
  title: 'Comparison Between Exports between China and USA',
};

 

Plotly.newPlot('myDiv', data,layout); </script>
</div>
</div>
";

echo '</section>';

echo '<section class="raw">';

echo '<div class="col-md-2">

</div>';
echo '<div class="col-md-8">';
 echo '<div id="myDivision" >';
 echo "<script>
 
 


var traces1 = {
  x:".$seriesyear2.",
  y:".$seriesvalues2.",
  name: 'China to US',
  marker: {color: 'rgb(55, 83, 109)'},
  type: 'bar'
};

var traces2 = {
  x:".$seriesyear1.",
  y:".$seriesvalues1.",
  name: 'US to China',
  marker: {color: 'rgb(26, 118, 255)'},
  type: 'bar'
};

var datta = [traces1, traces2];

var layout = {
  title: 'US CHINA TRADE',
  xaxis: {tickfont: {
      size: 14,
      color: 'rgb(107, 107, 107)'
    }},
  yaxis: {
    title: 'USD (millions)',
    titlefont: {
      size: 16,
      color: 'rgb(107, 107, 107)'
    },
    tickfont: {
      size: 14,
      color: 'rgb(107, 107, 107)'
    }
  },
  legend: {
    x: 0,
    y: 1.0,
    bgcolor: 'rgba(255, 255, 255, 0)',
    bordercolor: 'rgba(255, 255, 255, 0)'
  },
  barmode: 'group',
  bargap: 0.15,
  bargroupgap: 0.1
};

Plotly.newPlot('myDivision', datta, layout); </script>
</div>
</div>
";









 
  

?>

</section>

   <!-- Javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.0.min.js"><\/script>')</script>
    <script src="js/wow.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>




